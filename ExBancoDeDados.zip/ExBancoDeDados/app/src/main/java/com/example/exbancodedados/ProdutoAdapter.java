package com.example.exbancodedados;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import kotlin.collections.ArrayDeque;

public class ProdutoAdapter
        extends RecyclerView.Adapter<ProdutoAdapter.ProdutoViewHolder> {

    private List<Produto> produtos = new ArrayDeque<>();

    @NonNull
    @Override
    public ProdutoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_produto, parent, false);
        return new ProdutoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProdutoViewHolder holder, int position) {
        Produto produto = produtos.get(position);
        holder.txtCodigo.setText("Código: " + produto.getCodigo());
        holder.txtDescricao.setText("Descrição: " + produto.getDescricao());
        holder.txtValor.setText(String.format("Valor: R$ %.2f", + produto.getValor()));
    }

    @Override
    public int getItemCount() {
        return produtos.size();
    }

    public static class ProdutoViewHolder extends RecyclerView.ViewHolder {
        TextView txtCodigo, txtDescricao, txtValor;
        public ProdutoViewHolder(@NonNull View itemView) {
            super(itemView);
            txtCodigo = itemView.findViewById(R.id.textCodigo);
            txtDescricao = itemView.findViewById(R.id.textDescricao);
            txtValor = itemView.findViewById(R.id.textValor);
        }
    }

}
