package com.example.exbancodedados;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.exbancodedados.databinding.ActivityAddProductBinding;

public class AddProductActivity extends AppCompatActivity {

    private AppDataBase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        ActivityAddProductBinding binding = ActivityAddProductBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = AppDataBase.getDataBase(getApplicationContext());

        binding.btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String codigo = binding.edtCodigo.getText().toString();
                final String descricao = binding.edtDescricao.getText().toString();
                final double valor = Double.parseDouble(binding.edtValor.getText().toString());
                db.produtoDao().inserir(new Produto(codigo, descricao, valor));

                Toast.makeText(AddProductActivity.this, "Produto Salvo",
                        Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}