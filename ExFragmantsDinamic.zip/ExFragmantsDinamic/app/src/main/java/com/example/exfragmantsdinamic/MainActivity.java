package com.example.exfragmantsdinamic;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private FragmentManager fm;
    private UpFragment upFragment;
    private DownFragment downFragment;
    private FragmentTransaction ft;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnFrag1 = findViewById(R.id.btnFrag1);
        Button btnFrag2 = findViewById(R.id.btnFrag2);

        btnFrag1.setOnClickListener(this);
        btnFrag2.setOnClickListener(this);


        fm = getSupportFragmentManager();
        upFragment = new UpFragment();
        downFragment = new DownFragment();
//        
//        FragmentTransaction ft = fm.beginTransaction();
//        ft.setReorderingAllowed(true);
//        ft.add(R.id.fragment1, upFragment, "Up");
//        ft.add(R.id.fragment2, downFragment, "Down");
//        ft.commit();

    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnFrag1){
            ft = fm.beginTransaction();
            ft.setReorderingAllowed(true);
            ft.add(R.id.fragment1, upFragment, "Up");
            ft.commit();
        }else if (view.getId() == R.id.btnFrag2){
            ft = fm.beginTransaction();
            ft.setReorderingAllowed(true);
            ft.add(R.id.fragment2, downFragment, "Down");
            ft.commit();
        }
    }
}