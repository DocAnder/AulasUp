package com.example.exasynctask;


import android.os.AsyncTask;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class ProcessarTask extends AsyncTask<Integer, Integer, Void> {

    private Button btnProcessar;
    private TextView txtCounter;

    public ProcessarTask(Button btnProcessar, TextView txtCounter) {
        this.btnProcessar = btnProcessar;
        this.txtCounter = txtCounter;
    }

    @Override
    protected void onPreExecute(){
        super.onPreExecute();
        btnProcessar.setEnabled(false);
    }

    @Override
    protected Void doInBackground(Integer... integers) {
        int max = integers[0];
        for (int i = max; i >= 0; i--){
            SystemClock.sleep(1000);
            publishProgress(i);
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Integer...values){
        super.onProgressUpdate();
        int progresso = values[0];
        txtCounter.setText(String.valueOf(progresso));
    }

    @Override
    protected void onPostExecute(Void unused){
        super.onPostExecute(unused);
        btnProcessar.setEnabled(true);
    }


}
