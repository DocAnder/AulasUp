package com.example.exbd;

import android.content.Intent;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.exbd.databinding.ActivityMainBinding;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity implements ConsoleAdapter.OnItemClickListener {

    private AppDatabase db;
    private ConsoleAdapter consoleAdapter;
    private ExecutorService executorService;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Inicializar a base de dados
        db = AppDatabase.getDatabase(getApplicationContext());

        // Inicializar o ExecutorService
        executorService = Executors.newSingleThreadExecutor();

        // Configurar o RecyclerView e o Adapter
        binding.recyclerViewProdutos.setLayoutManager(new LinearLayoutManager(this));
        consoleAdapter = new ConsoleAdapter(this);
        consoleAdapter.setOnItemClickListener(this); // Configurar o listener
        binding.recyclerViewProdutos.setAdapter(consoleAdapter);

        // Observar as mudanças na lista de produtos
        db.consoleDao().listar().observe(this, new Observer<List<Console>>() {
            @Override
            public void onChanged(List<Console> consoles) {
                consoleAdapter.setConsoles(consoles);
            }
        });

        binding.fabDataDev.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DataDevActivity.class);
            startActivity(intent);
        });


        // Configurar o FloatingActionButton
        binding.fabAdicionar.setOnClickListener(v -> {
            // Navegar para a atividade de adicionar produto
            Intent intent = new Intent(MainActivity.this, AddConsoleActivity.class);
            startActivity(intent);
        });
    }

    @Override
    public void onItemClick(Console console) {
        // Navegar para a atividade de edição de console
        Intent intent = new Intent(MainActivity.this, EditConsoleActivity.class);
        intent.putExtra("produto_id", console.getId());
        startActivity(intent);
    }

    public void deletarConsole(Console console) {
        executorService.execute(() -> {
            db.consoleDao().deletar(console);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }
}