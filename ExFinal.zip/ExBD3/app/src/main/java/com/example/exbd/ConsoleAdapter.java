package com.example.exbd;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ConsoleAdapter extends RecyclerView.Adapter<ConsoleAdapter.ConsoleViewHolder> {
    private List<Console> consoles = new ArrayList<>();
    private OnItemClickListener listener;
    private Context context;


    public interface OnItemClickListener {
        void onItemClick(Console console);
    }

    public ConsoleAdapter(Context context) {
        this.context = context;
    }

    public void setConsoles(List<Console> consoles) {
        this.consoles.clear();
        this.consoles.addAll(consoles);
        notifyDataSetChanged();
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @Override
    public ConsoleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_console, parent, false);
        return new ConsoleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ConsoleViewHolder holder, int position) {
        Console console = consoles.get(position);
        holder.textMarca.setText("Marca: " + console.getMarca());
        holder.textModelo.setText("Modelo: " + console.getModelo());
        holder.textValor.setText(String.format("Valor: R$ %.2f", console.getValor()));

        // Clique no item para editar
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(console);
            }
        });

        // Clique no botão de deletar
        holder.btnDelete.setOnClickListener(v -> {
            // Exibir um diálogo de confirmação
            new AlertDialog.Builder(context)
                    .setTitle("Excluir Console")
                    .setMessage("Tem certeza que deseja excluir este console?")
                    .setPositiveButton("Sim", (dialog, which) -> {
                        if (context instanceof MainActivity) {
                            ((MainActivity) context).deletarConsole(console);
                        }
                    })
                    .setNegativeButton("Não", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return consoles != null ? consoles.size() : 0;
    }

    public static class ConsoleViewHolder extends RecyclerView.ViewHolder {
        TextView textMarca, textModelo, textValor;
        ImageButton btnDelete;

        public ConsoleViewHolder(View itemView) {
            super(itemView);
            textMarca = itemView.findViewById(R.id.textMarca);
            textModelo = itemView.findViewById(R.id.textModelo);
            textValor = itemView.findViewById(R.id.textValor);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
