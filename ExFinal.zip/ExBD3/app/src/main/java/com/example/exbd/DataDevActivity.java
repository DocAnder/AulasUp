package com.example.exbd;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.exbd.databinding.ActivityDataDevBinding;
import com.example.exbd.databinding.ActivityEditConsoleBinding;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DataDevActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        ActivityDataDevBinding binding = ActivityDataDevBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
    }
}