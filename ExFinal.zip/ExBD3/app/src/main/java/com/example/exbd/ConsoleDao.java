package com.example.exbd;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ConsoleDao {
    @Insert
    void inserir(Console console);

    @Update
    void atualizar(Console console);

    @Delete
    void deletar(Console console);

    @Query("SELECT * FROM Console")
    LiveData<List<Console>> listar();

    @Query("SELECT * FROM Console WHERE id = :id LIMIT 1")
    Console SelectId(int id);

}
