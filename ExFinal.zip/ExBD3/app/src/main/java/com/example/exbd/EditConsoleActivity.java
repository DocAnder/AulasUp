package com.example.exbd;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.exbd.databinding.ActivityEditConsoleBinding;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EditConsoleActivity extends AppCompatActivity {

    private AppDatabase db;
    private ExecutorService executorService;
    private Console console;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        ActivityEditConsoleBinding binding = ActivityEditConsoleBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obter a instância Singleton do banco de dados
        db = AppDatabase.getDatabase(getApplicationContext());

        executorService = Executors.newSingleThreadExecutor();

        // Obter o ID do console a partir da Intent
        int produtoId = getIntent().getIntExtra("produto_id", -1);

        if (produtoId != -1) {
            // Carregar o console do banco de dados
            executorService.execute(() -> {
                console = db.consoleDao().SelectId(produtoId);
                runOnUiThread(() -> {
                    if (console != null) {
                        // Preencher os campos com os dados do console
                        binding.editMarca.setText(console.getMarca());
                        binding.editModelo.setText(console.getModelo());
                        binding.editValor.setText(String.valueOf(console.getValor()));
                    }
                });
            });
        }

        binding.btnAtualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String marca = binding.editMarca.getText().toString();
                final String modelo = binding.editModelo.getText().toString();
                final double valor;

                try {
                    valor = Double.parseDouble(binding.editValor.getText().toString());
                } catch (NumberFormatException e) {
                    Toast.makeText(EditConsoleActivity.this, "Valor inválido!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Atualizar o console
                executorService.execute(() -> {
                    console.setMarca(marca);
                    console.setModelo(modelo);
                    console.setValor(valor);
                    db.consoleDao().atualizar(console);

                    // Voltar à thread principal para atualizar a UI
                    runOnUiThread(() -> {
                        Toast.makeText(EditConsoleActivity.this, "Console atualizado!", Toast.LENGTH_SHORT).show();
                        finish();
                    });
                });
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }
}