package br.com.ifpr.persistproject.connection;

import br.com.ifpr.persistproject.repository.SellerRepository;

import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionTest {

    public static void main(String[] args) {

        SellerRepository sellerRepository = new SellerRepository();

        sellerRepository.getSellers();

    }
}
